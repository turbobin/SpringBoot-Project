package com.ccb.dubbo.consumer.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.ccb.dubbo.common.service.UserService;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping(value = "user")
public class UserController {

    @Reference(version = "1.0.0")
    public UserService userService;

    @RequestMapping(value = "/all")
    public Object findAllUsers(){
        return userService.findAllUsers();
    }

    @RequestMapping(value = "/{id}")
    public Object findUserById(@PathVariable("id") Integer userId){
        return userService.findUserById(userId);
    }

    @RequestMapping("/sayHello/{name}")
    public String sayHello(@PathVariable("name") String name) {
        return userService.sayHello(name);
    }


}
